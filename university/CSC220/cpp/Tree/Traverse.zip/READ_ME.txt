Please compile and run tree.cc
